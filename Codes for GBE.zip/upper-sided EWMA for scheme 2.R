library(MASS)
lambda<-0.01   #Parameter r
m<-400         #Number of interval divisions N
l=2*m+1 
UCL<-0.0936     #upper control limit (UCL)
LCL<--1/sqrt(pi-1)  #lower control limit (LCL)
delta01=1  #IC scale parameter theta10
delta02=2  #IC scale parameter theta20
d=0.25     #IC dependence parameter
delta11<-delta01*1   #OOC scale parameter theta11
delta12<-delta02*1   #OOC scale parameter theta12   

rate0=((1/delta01)^(1/d)+(1/delta02)^(1/d))^(-d) #IC parameter of exponential distribution
rate1=((1/delta11)^(1/d)+(1/delta12)^(1/d))^(-d) #OOC parameter of exponential distribution

CL=(UCL-LCL)/(2*m+1)
A2<-matrix(0,l,l)
for(i in 1:l)
  for(j in 1:l)
  {A2[i,j]<-(LCL+(j-0.5)*CL+0.5*CL-(1-lambda)*(LCL+(i-0.5)*CL))/lambda*sqrt(0.5-1/(2*pi))+1/sqrt(2*pi)
  }
A2[A2<0]=-100

A1<-matrix(0,l,l)
for(i in 1:l)
  for(j in 1:l)
  {A1[i,j]<-(LCL+(j-0.5)*CL-0.5*CL-(1-lambda)*(LCL+(i-0.5)*CL))/lambda*sqrt(0.5-1/(2*pi))+1/sqrt(2*pi)
  }
A1[A1<0]=-100
A1[A2<0]=-100

p<-matrix(0,l,l)
for(i in 1:l)
  for(j in 1:l)
  {p[i,j]<-pexp(qexp(pnorm(A2[i,j]),1/rate0),1/rate1)-
    pexp(qexp(pnorm(A1[i,j]),1/rate0),1/rate1)
  }

d<-c()
A3<-c()
A4<-c()
for(j in 1:l)
{A3[j]<-LCL+(j-0.5)*CL-0.5*CL
A4[j]<-LCL+(j-0.5)*CL+0.5*CL
if(0>A3[j] & 0<A4[j]){d[j]=1} else {d[j]=0}
}
a<-matrix(p,2*m+1,2*m+1)
b<-diag(2*m+1)
c<-ginv(b-a)
x<-c(0*1:m)

e<-matrix(1,2*m+1,1)
ARL<-d%*%c%*%e
ATS<-ARL*rate1
ATS