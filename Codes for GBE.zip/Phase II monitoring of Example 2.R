library(MASS)
data<-read.csv("DRS1.csv",header=F)  #Importing the Example 2 dataset
X1<-as.matrix(data)
X<-t(X1)
Y<-apply(X,2,min)
mu_hat<-apply(X[,1:30],1,mean)
var_cov_mat_hat<-1/(30-1)*(X[,1:30]-mu_hat)%*%t(X[,1:30]-mu_hat)
aa<-apply(apply(X[,1:30]/mu_hat,2,sort),1,mean)
d1<--log2(aa[1])
delta01<-35.66     #IC scale parameter theta10
delta02<-28.89     #IC scale parameter theta20
d=0.46             #IC dependence parameter
rate0=((1/delta01)^(1/d)+(1/delta02)^(1/d))^(-d)  #IC parameter of exponential distribution
Y1<-qnorm(pexp(Y,1/rate0))   #standard normal inversion

teta1 = 35.66             
teta2 = 28.89
r=0.01  #Parameter r
K=0.02  #Parameter k
z=0
S1=rate0
S2=0
S3=1
S4=0
S<- matrix(c(0,0))
Q<-c()
E2<-c()
U1<-c()
U2<-c()
U3<-c()
U4<-c()
X<-X[,31:80]
Y1<-Y1[31:80]
Y2<-Y[31:80]
for(t in 1:50){
  z = r*(X[,t] - mu_hat) + (1-r)*z
  E2[t] = (2-r)/r*(t(z)%*%ginv(var_cov_mat_hat)%*%z)
  
  C = (t(S+X[,t]-mu_hat)%*%ginv(var_cov_mat_hat)%*%(S+X[,t]-mu_hat))^(1/2)
  if (C<=K) {S=matrix(c(0,0))}
  else {S=(S+X[,t]-mu_hat)%*%(1-K/C)}
  Q[t] = (t(S)%*%ginv(var_cov_mat_hat)%*%S)^(1/2)
  
  S1 = r*Y2[t] + (1-r)*S1
  U1[t]=S1
  
  S2 = r*Y1[t] + (1-r)*S2
  U2[t]=S2
  
  S3<-r*(min(1,Y2[t]/rate0)/(1-exp(-1)))+(1-r)*S3
  U3[t]=S3
  
  S4<-r*((min(0,Y1[t])+1/sqrt(2*pi))/sqrt(0.5-1/(2*pi)))+(1-r)*S4
  U4[t]=S4
}

pdf("C:/Users/chenpeile/Desktop/EWMA.pdf",family="GB1",width=10,height=8.5)
par(mfrow=c(3,2)) 
#MEWMA
par(mai=c(0.5,0.6,0.5,0.2))
h=0.67
sample.number <- as.factor(1:50)
plot(x=c(1,50),y=c(0,4),lwd=2,yaxt="n",xaxt="n",type = 'n',xlab = 'Event Number',ylab = 'plotting-statiistic',cex.axis=1,cex.lab=1)
axis(side=2,las=2,cex.axis=1,lwd=1)
axis(side=1,las=1,cex.axis=1,xaxp=c(0,50,5),lwd=1)
lines(c(-10,110),c(h,h),lty=5,lwd=1)
lines(E2,lwd=1)
points(sample.number,E2,pch=ifelse(E2>h,15,16),cex=1)
title(main = expression(paste(MEWMA)),cex.main = 1.25)

#MCUSUM
par(mai=c(0.5,0.6,0.5,0.2))
h=5.92
sample.number <- as.factor(1:50)
plot(x=c(1,50),y=c(0,15),lwd=2,yaxt="n",xaxt="n",type = 'n',xlab = 'Event Number',ylab = 'plotting-statiistic',cex.axis=1,cex.lab=1)
axis(side=2,las=2,cex.axis=1,lwd=1)
axis(side=1,las=1,cex.axis=1,xaxp=c(0,50,5),lwd=1)
lines(c(-10,110),c(h,h),lty=5,lwd=1)
lines(Q,lwd=1)
points(sample.number,Q,pch=ifelse(Q>h,15,16),cex=1)
title(main = expression(paste(MCUSUM)),cex.main = 1.25)

#GBE-EWMA-TS-1
par(mai=c(0.5,0.6,0.5,0.2))
h=21.52
h2=24.04
sample.number <- as.factor(1:50)
plot(x=c(1,50),y=c(21,25),lwd=2,yaxt="n",xaxt="n",type = 'n',xlab = 'Event Number',ylab = 'plotting-statiistic',cex.axis=1,cex.lab=1)
axis(side=2,las=2,cex.axis=1,lwd=1)
axis(side=1,las=1,cex.axis=1,xaxp=c(0,50,5),lwd=1)
lines(c(-10,110),c(h,h),lty=5,lwd=1)
lines(c(-10,110),c(h2,h2),lty=5,lwd=1)
lines(U1,lwd=1)
points(sample.number,U1,pch=ifelse(U1<h,15,16),cex=1)
title(main = expression(paste(GBE-EWMA-TS-1)),cex.main = 1.25)


#GBE-EWMA-TS-2
par(mai=c(0.5,0.6,0.5,0.2))
h=-0.05597468
h2=0.05597468
sample.number <- as.factor(1:50)
plot(x=c(1,50),y=c(0.1,-0.1),lwd=2,yaxt="n",xaxt="n",type = 'n',xlab = 'Event Number',ylab = 'plotting-statiistic',cex.axis=1,cex.lab=1)
axis(side=2,las=2,cex.axis=1,lwd=1)
axis(side=1,las=1,cex.axis=1,xaxp=c(0,50,5),lwd=1)
lines(c(-10,110),c(h,h),lty=5,lwd=1)
lines(c(-10,110),c(h2,h2),lty=5,lwd=1)
lines(U2,lwd=1)
points(sample.number,U2,pch=ifelse(U2<h,15,16),cex=1)
title(main = expression(paste(GBE-EWMA-TS-2)),cex.main = 1.25)


#GBE-EWMA-OS-1
par(mai=c(0.55,0.6,0.5,0.2))
h=0.9911476 
sample.number <- as.factor(1:50)
plot(x=c(1,50),y=c(0.94,1.05),lwd=2,yaxt="n",xaxt="n",type = 'n',xlab = 'Event Number',ylab = 'plotting-statiistic',cex.axis=1,cex.lab=1)
axis(side=2,las=2,cex.axis=1,lwd=1)
axis(side=1,las=1,cex.axis=1,xaxp=c(0,50,5),lwd=1)
lines(c(-10,110),c(h,h),lty=5,lwd=1)
lines(U3,lwd=1)
points(sample.number,U3,pch=ifelse(U3<h,15,16),cex=1)
title(main = expression(paste(GBE-EWMA-OS-1)),cex.main = 1.25)

#GBE-EWMA-OS-2
par(mai=c(0.55,0.6,0.5,0.2))
h=-0.01304492
sample.number <- as.factor(1:50)
plot(x=c(1,50),y=c(0.06,-0.08),lwd=2,yaxt="n",xaxt="n",type = 'n',xlab = 'Event Number',ylab = 'plotting-statiistic',cex.axis=1,cex.lab=1)
axis(side=2,las=2,cex.axis=1,lwd=1)
axis(side=1,las=1,cex.axis=1,xaxp=c(0,50,5),lwd=1)
lines(c(-10,110),c(h,h),lty=5,lwd=1)
lines(U4,lwd=1)
points(sample.number,U4,pch=ifelse(U4<h,15,16),cex=1)
title(main = expression(paste(GBE-EWMA-OS-2)),cex.main = 1.25)


dev.off()
