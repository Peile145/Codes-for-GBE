library(foreach)
library(iterators)
library(parallel)
library(doParallel)

r= 0.01   #Parameter r
UCL=3.57  #control limit

rep<-100000  #Number of simulations
teta1 = 1    #IC scale parameter theta10
teta2 = 2    #IC scale parameter theta20
d = 0.25     #IC dependence parameter

mu_hat1 = teta1
mu_hat2 = teta2
mu_hat = c(mu_hat1,mu_hat2) #mean vector
var_cov_mat_hat = matrix(c(teta1^2,teta1*teta2*(2*((gamma(d+1))^2)/gamma(2*d+1)-1),
                           teta1*teta2*(2*((gamma(d+1))^2)/gamma(2*d+1)-1),teta2^2),2,2) #covariance matrix
var<-solve(var_cov_mat_hat)
ATS<-vector(mode = "numeric",length = 1)


k0<-1

X=matrix(0,nrow=10001,ncol=2)
z=c()
cl<-makeCluster(detectCores())  
registerDoParallel(cl)
rls<-foreach(j0=1:rep,.combine = 'c')%dopar%{
  for (count in 1:10000){ 

    U=runif(1)
    M = runif(1)<d
    V11=rexp(1)
    V12=rexp(1)
    V=V11+M*V12
    X1=teta1*(U^d)*V
    X2=teta2*((1-U)^d)*V
    X[count,] = matrix(c(X1,X2))
    
    z<- matrix(c(0,0))

    for(t in 1:count){
      z = r*(X[t,] - mu_hat) + (1-r)*z
      E2 = (2-r)/r*(t(z)%*%var%*%z)
    }
    
    if( E2>UCL ) break
  }
  
  rl<-count
  TS=sum(apply(X[1:(rl+1),],1,max))
  TS
}
ATS<-mean(rls)
ATS


