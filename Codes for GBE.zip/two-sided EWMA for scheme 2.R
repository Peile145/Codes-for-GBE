library(MASS)
  lambda<-0.01  #Parameter r
  m<-400     #Number of interval divisions N
  delta01=1  #IC scale parameter theta10
  delta02=2  #IC scale parameter theta20
  d=0.25     #IC dependence parameter
  delta11<-delta01*1    #OOC scale parameter theta11
  delta12<-delta02*1    #OOC scale parameter theta12
  
  rate0=((1/delta01)^(1/d)+(1/delta02)^(1/d))^(-d) #IC parameter of exponential distribution
  rate1=((1/delta11)^(1/d)+(1/delta12)^(1/d))^(-d) #OOC parameter of exponential distribution
  L=1.827   #Control threshold coefficient L
  UCL<-L*sqrt(lambda/(2-lambda))  #upper control limit (UCL)
  CL<-2*UCL/(2*m+1)
  p<-matrix(0,2*m+1,2*m+1)
  for(i in 1:(2*m+1))  #Transfer probability matrix
    for(j in 1:(2*m+1))
    {p[i,j]<-pexp(qexp(pnorm((-UCL+(j-0.5)*CL+CL/2-(1-lambda)*(-UCL+(i-0.5)*CL))/lambda),1/rate0),1/rate1)-
      pexp(qexp(pnorm((-UCL+(j-0.5)*CL-CL/2-(1-lambda)*(-UCL+(i-0.5)*CL))/lambda),1/rate0),1/rate1)
    }
  a<-matrix(p,2*m+1,2*m+1)
  b<-diag(2*m+1)
  c<-ginv(b-a)
  x<-c(0*1:m)
  d<-matrix(c(x,1,x),1,2*m+1)
  e<-matrix(1,2*m+1,1)
  ARL<-d%*%c%*%e
  ATS<-ARL*rate1
  ATS
