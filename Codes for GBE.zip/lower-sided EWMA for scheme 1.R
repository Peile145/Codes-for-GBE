library("MASS")
    lambda<-0.01  #Parameter r
    LCL<-0.9475   #lower control limit (LCL)
    UCL=1/(1-exp(-1))  #upper control limit (UCL)
    delta01=1  #IC scale parameter theta10
    delta02=2  #IC scale parameter theta20
    d=0.25     #IC dependence parameter
    delta11<-delta01*1   #OOC scale parameter theta11
    delta12<-delta02*1   #OOC scale parameter theta12
    
    rate0=((1/delta01)^(1/d)+(1/delta02)^(1/d))^(-d) #IC parameter of exponential distribution
    rate1=((1/delta11)^(1/d)+(1/delta12)^(1/d))^(-d) #OOC parameter of exponential distribution
    m<-400   #Number of interval divisions N
    l=2*m+1
    
    
    delta<-rate1/rate0
    
    CL=(UCL-LCL)/(2*m+1)
    A2<-matrix(0,l,l)
    for(i in 1:l)  #Transfer probability matrix
      for(j in 1:l)   
      {A2[i,j]<-(UCL-(j-0.5)*CL+0.5*CL-(1-lambda)*(UCL-(i-0.5)*CL))/lambda*(1-exp(-1))
      }
    
    
    A1<-matrix(0,l,l)
    for(i in 1:l)
      for(j in 1:l)
      {A1[i,j]<-(UCL-(j-0.5)*CL-0.5*CL-(1-lambda)*(UCL-(i-0.5)*CL))/lambda*(1-exp(-1))
      }
    A2[A1>1]=0
    A1[A1>1]=0
    
    A2[A2>1]=100
    
    
    p<-matrix(0,l,l)
    for(i in 1:l)
      for(j in 1:l)
      {p[i,j]<-pexp(A2[i,j]/delta)-pexp(A1[i,j]/delta)
      }
    
    d<-c()
    A3<-c()
    A4<-c()
    for(j in 1:l)
    {A3[j]<-UCL-(j-0.5)*CL-0.5*CL
    A4[j]<-UCL-(j-0.5)*CL+0.5*CL
    if(1>A3[j] & 1<A4[j]){d[j]=1} else {d[j]=0}
    }
    a<-matrix(p,2*m+1,2*m+1)
    b<-diag(2*m+1)
    c<-ginv(b-a)
    x<-c(0*1:m)
    
    e<-matrix(1,2*m+1,1)
    ARL<-d%*%c%*%e
    ATS<-ARL*rate1
    ATS

