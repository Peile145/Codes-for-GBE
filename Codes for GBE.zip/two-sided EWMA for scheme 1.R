library(MASS)  
r<-0.01  #Parameter r
  delta01=1  #IC scale parameter theta10
  delta02=2  #IC scale parameter theta20
  d=0.25     #IC dependence parameter
  delta11=1*1  #OOC scale parameter theta11
  delta12=2*1  #OOC scale parameter theta12
  rate0=((1/delta01)^(1/d)+(1/delta02)^(1/d))^(-d) #IC parameter of exponential distribution
  rate1=((1/delta11)^(1/d)+(1/delta12)^(1/d))^(-d) #OOC parameter of exponential distribution
  L11=1.674   #Control threshold coefficient L11
  L12=1.9458  #Control threshold coefficient L12
  UCL=rate0+L11*sqrt(r/(2-r))*rate0  #upper control limit (UCL)
  LCL=rate0-L12*sqrt(r/(2-r))*rate0  #lower control limit (LCL)
  
  
  p<-400  #Number of interval divisions N
  m<-2*p+1
  san<-(UCL-LCL)/(2*m)
  
  pij<-matrix(0,m,m)  
  for(i in 1:m)   #Transfer probability matrix
    for(j in 1:m)
    {pij[i,j]<-pexp((LCL+(2*j-1)*san+san-(1-r)*(LCL+(2*i-1)*san))/r,1/rate1)-
      pexp((LCL+(2*j-1)*san-san-(1-r)*(LCL+(2*i-1)*san))/r,1/rate1)
    }
  b<-diag(m)
  c<-ginv(b-pij)
  x<-c(0*1:p)
  d<-matrix(c(x,1,x),1,m)
  e<-matrix(1,m,1)
  ARL<-d%*%c%*%e
  ATS<-ARL*rate1
  ATS
