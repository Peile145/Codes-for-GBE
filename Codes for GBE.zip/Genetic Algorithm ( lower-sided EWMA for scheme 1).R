library("MASS")
f<-function(x){
  lambda<-x[1]   #Parameter r
  fr<-function(L) {
    LCL<-1-L*sqrt(lambda/(2-lambda)*(1-exp(-1)*(2+exp(-1))))*(1-exp(-1))
    UCL=1/(1-exp(-1)) 
    delta01=1  #IC scale parameter theta10
    delta02=2  #IC scale parameter theta20
    d=0.5     #IC dependence parameter
    delta11<-delta01*1   #OOC scale parameter theta11
    delta12<-delta02*1   #OOC scale parameter theta12 
    
    rate0=((1/delta01)^(1/d)+(1/delta02)^(1/d))^(-d) #IC parameter of exponential distribution
    rate1=((1/delta11)^(1/d)+(1/delta12)^(1/d))^(-d) #OOC parameter of exponential distribution
    m<-400   #Number of interval divisions N
    l=2*m+1
    
    
    delta<-rate1/rate0
    
    CL=(UCL-LCL)/(2*m+1)
    A2<-matrix(0,l,l)
    for(i in 1:l)
      for(j in 1:l)   
      {A2[i,j]<-(UCL-(j-0.5)*CL+0.5*CL-(1-lambda)*(UCL-(i-0.5)*CL))/lambda*(1-exp(-1))
      }
    
    
    A1<-matrix(0,l,l)
    for(i in 1:l)
      for(j in 1:l)
      {A1[i,j]<-(UCL-(j-0.5)*CL-0.5*CL-(1-lambda)*(UCL-(i-0.5)*CL))/lambda*(1-exp(-1))
      }
    A2[A1>1]=0
    A1[A1>1]=0
    
    A2[A2>1]=100
    
    
    p<-matrix(0,l,l)
    for(i in 1:l)
      for(j in 1:l)
      {p[i,j]<-pexp(A2[i,j]/delta)-pexp(A1[i,j]/delta)
      }
    
    d<-c()
    A3<-c()
    A4<-c()
    for(j in 1:l)
    {A3[j]<-UCL-(j-0.5)*CL-0.5*CL
    A4[j]<-UCL-(j-0.5)*CL+0.5*CL
    if(1>A3[j] & 1<A4[j]){d[j]=1} else {d[j]=0}
    }
    a<-matrix(p,2*m+1,2*m+1)
    b<-diag(2*m+1)
    c<-ginv(b-a)
    x<-c(0*1:m)
    
    e<-matrix(1,2*m+1,1)
    ARL<-d%*%c%*%e
    ATS<-ARL*rate0-370
    return(ATS)
  }
  
  R<-uniroot(fr,c(4,6),extendInt="yes",trace=2) #Find the control limit coefficient for ATS=370 from the given r
  L<-R$root
  
  LCL<-1-L*sqrt(lambda/(2-lambda)*(1-exp(-1)*(2+exp(-1))))*(1-exp(-1))
  UCL=1/(1-exp(-1))
  delta01<-1    
  delta02<-2   
  d=0.5
  delta11<-delta01*0.9   #OOC scale parameter theta11
  delta12<-delta02*0.9   #OOC scale parameter theta12  
  
  rate0=((1/delta01)^(1/d)+(1/delta02)^(1/d))^(-d)
  rate1=((1/delta11)^(1/d)+(1/delta12)^(1/d))^(-d)
  m<-400   
  l=2*m+1
  delta<-rate1/rate0
  
  CL=(UCL-LCL)/(2*m+1)
  A2<-matrix(0,l,l)
  for(i in 1:l)
    for(j in 1:l)   
    {A2[i,j]<-(UCL-(j-0.5)*CL+0.5*CL-(1-lambda)*(UCL-(i-0.5)*CL))/lambda*(1-exp(-1))
    }
  
  
  A1<-matrix(0,l,l)
  for(i in 1:l)
    for(j in 1:l)
    {A1[i,j]<-(UCL-(j-0.5)*CL-0.5*CL-(1-lambda)*(UCL-(i-0.5)*CL))/lambda*(1-exp(-1))
    }
  A2[A1>1]=0
  A1[A1>1]=0
  
  A2[A2>1]=100
  
  
  p<-matrix(0,l,l)
  for(i in 1:l)
    for(j in 1:l)
    {p[i,j]<-pexp(A2[i,j]/delta)-pexp(A1[i,j]/delta)
    }
  
  d<-c()
  A3<-c()
  A4<-c()
  for(j in 1:l)
  {A3[j]<-UCL-(j-0.5)*CL-0.5*CL
  A4[j]<-UCL-(j-0.5)*CL+0.5*CL
  if(1>A3[j] & 1<A4[j]){d[j]=1} else {d[j]=0}
  }
  a<-matrix(p,2*m+1,2*m+1)
  b<-diag(2*m+1)
  c<-ginv(b-a)
  x<-c(0*1:m)
  
  e<-matrix(1,2*m+1,1)
  ARL<-d%*%c%*%e
  ATS<-ARL*rate1
  return(ATS)
}
optim(0.05,fn=f,method="L-BFGS-B",lower=0.01,upper=1) #L-BFGS-B genetic algorithm,given a search range of r(0.01 to 1)

